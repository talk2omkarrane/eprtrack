# EPRTrack V14 — Position + Evidence workflow

V14 changes the logged-in workspace from a manual checklist into a position-and-evidence workflow.

## What changed

- Dashboard starts with the business-data position, not a manual checklist.
- Latest browser-side Excel health check feeds the planning basis.
- Verified EPR target is shown when it exists, but is not required just to see the data position.
- Fulfilment evidence can be recorded in a semi-manual ledger.
- Only evidence marked **Confirmed by user** contributes to evidence-backed fulfilment.
- Dashboard shows:
  - planning basis
  - verified target
  - evidence-backed fulfilment
  - open planning/target gap
  - progress
  - why the gap exists
  - latest data-health result
- Added a plain-English SEO blog article for 18 September 2026.
- Added blog URLs to sitemap.
- Payment remains disabled; no payment page or gateway is introduced.

## Important V14 testing boundary

This first reconciliation ledger is deliberately semi-manual. Evidence metadata is stored in browser `localStorage` for the test build; certificate files are **not uploaded to the Worker**.

That is intentional for validation before building persistent evidence storage and automatic matching.

## Install into the existing EPRTrack repository

Copy:

- `public/dashboard/index.html`
- `public/v14.css`
- `public/blog/index.html`
- `public/blog/epr-data-reconciliation/index.html`
- `public/sitemap.xml`

No Worker/D1 schema change is required for this V14 front-end test.

The existing V12/V13 analyzer and authentication endpoints remain in place.

## Test sequence

1. Sign in.
2. Open Dashboard.
3. Confirm the latest analyzer result appears.
4. Add one fulfilment evidence record as `Needs review`.
5. Confirm it does **not** increase evidence-backed fulfilment.
6. Add/mark a record as `Confirmed by user`.
7. Confirm fulfilled quantity and open gap update.
8. Refresh the page and confirm evidence remains in the same browser.
9. Sign out and sign back in; confirm server authentication still works.
10. Test at 1366x768, 1440x900, tablet width and mobile width.
11. Open the new blog page and confirm sitemap contains both blog URLs.

## Product boundary

EPRTrack is independent planning/reconciliation software. It does not determine or certify a legal EPR target and does not replace CPCB/Common EPR Portal records. Verify current official requirements before filing.

const CORS={"access-control-allow-origin":"*","access-control-allow-headers":"content-type,authorization","access-control-allow-methods":"GET,POST,PUT,DELETE,OPTIONS"};
const json=(data,status=200,extra={})=>new Response(JSON.stringify(data),{status,headers:{"content-type":"application/json",...CORS,...extra}});
const enc=new TextEncoder();
const roles=new Set(["producer","importer","brand-owner"]);
const labels={producer:"Producer",importer:"Importer", "brand-owner":"Brand Owner"};
const PBKDF2_ITERATIONS=10000; // Temporary Workers Free testing baseline; raise on a paid CPU budget before production.
const LEGACY_PBKDF2_ITERATIONS=600000;
function hex(bytes){return [...new Uint8Array(bytes)].map(x=>x.toString(16).padStart(2,"0")).join("")}
function bytesFromHex(h){return Uint8Array.from(h.match(/../g).map(x=>parseInt(x,16)))}
async function derivePassword(password,salt,iterations){
  const key=await crypto.subtle.importKey("raw",enc.encode(password),"PBKDF2",false,["deriveBits"]);
  const bits=await crypto.subtle.deriveBits({name:"PBKDF2",salt,iterations,hash:"SHA-256"},key,256);
  return hex(bits);
}
async function hashPassword(password){
  const salt=crypto.getRandomValues(new Uint8Array(16));
  const digest=await derivePassword(password,salt,PBKDF2_ITERATIONS);
  return `v2$${PBKDF2_ITERATIONS}$${hex(salt)}$${digest}`;
}
async function verifyPassword(password,stored){
  if(!stored)return false;
  let iterations=PBKDF2_ITERATIONS,saltHex,digest;
  const parts=stored.split("$");
  if(parts.length===4 && parts[0]==="v2"){iterations=Number(parts[1]);saltHex=parts[2];digest=parts[3];}
  else if(stored.includes(":")){[saltHex,digest]=stored.split(":");iterations=LEGACY_PBKDF2_ITERATIONS;}
  else return false;
  if(!Number.isInteger(iterations)||iterations<1000||!saltHex||!digest)return false;
  const actual=await derivePassword(password,bytesFromHex(saltHex),iterations);
  return actual===digest;
}
async function tableInfo(env,table){
  const allowed=new Set(["users","sessions","companies","compliance_profiles"]);
  if(!allowed.has(table))throw new Error("Invalid table");
  const rows=await env.DB.prepare(`PRAGMA table_info(${table})`).all();
  return rows.results||[];
}
async function columnType(env,table,column){
  const rows=await tableInfo(env,table);
  const c=rows.find(x=>x.name===column);
  if(!c)throw new Error(`${table}.${column} column not found`);
  return String(c.type||"").toUpperCase();
}
async function getSessionColumn(env){
  const rows=await tableInfo(env,"sessions");
  const names=rows.map(x=>x.name);
  if(names.includes("token"))return "token";
  if(names.includes("id"))return "id";
  throw new Error("Sessions table must contain id or token");
}
function isIntegerType(type){return /INT/i.test(type)}
function token(){const bytes=new Uint8Array(32);crypto.getRandomValues(bytes);return hex(bytes)}
function sessionCookie(value,maxAge=2592000){return `__Host-eprtrack_session=${value}; Path=/; Max-Age=${maxAge}; HttpOnly; Secure; SameSite=Strict`}
function clearSessionCookie(){return "__Host-eprtrack_session=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=Strict"}
function cookieValue(request,name="__Host-eprtrack_session"){const raw=request.headers.get("cookie")||"";for(const part of raw.split(";")){const [k,...v]=part.trim().split("=");if(k===name)return v.join("=")}return null}
function sameOrigin(request){const origin=request.headers.get("origin");return !origin||origin===new URL(request.url).origin}
async function auth(request,env){
  const sid=cookieValue(request); if(!sid)return null;
  const col=await getSessionColumn(env);
  return (await env.DB.prepare(`SELECT u.id,u.email FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.${col}=? AND s.expires_at>datetime('now')`).bind(sid).first())||null;
}
async function rules(env,request){const r=await env.ASSETS.fetch(new URL("/rules.json",request.url));if(!r.ok)throw new Error("Rules unavailable");return r.json()}
async function ownership(env,userId,companyId){return await env.DB.prepare("SELECT * FROM companies WHERE id=? AND user_id=?").bind(companyId,userId).first()}
async function ensureWorkspaceTasks(env){
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS workspace_tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    due_date TEXT,
    status TEXT NOT NULL DEFAULT 'open',
    priority TEXT NOT NULL DEFAULT 'normal',
    source_url TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at TEXT
  )`).run();
}
function fyEndYear(fy){const m=String(fy||'').match(/(\d{4})-(\d{2,4})/);return m?Number(m[1])+1:null}
async function seedWorkspaceTasks(env,company){
  await ensureWorkspaceTasks(env);
  const row=await env.DB.prepare("SELECT COUNT(*) AS n FROM workspace_tasks WHERE company_id=?").bind(company.id).first();
  if(Number(row?.n||0)>0)return;
  const end=fyEndYear(company.fy);
  const annualDue=end?`${end}-06-30`:null;
  const source='https://eprplastic.cpcb.gov.in/plastic/downloads/4th%20Amendment%20%28EPR%20guidelines%29%20Feb%202022.pdf';
  const tasks=[
    ['Verify your official EPR target','Enter the applicable target shown in your official CPCB records. EPRTrack does not determine the legal target in this version.',null,'high',null],
    ['Record achieved / credited quantity','Update the quantity you have evidence for as compliance activity progresses.',null,'normal',null],
    ['Prepare annual return','Keep annual-return data, recycler/PWP details and supporting records ready for filing.',annualDue,'high',source],
    ['Review CPCB updates','Check the Common EPR Portal and CPCB notices for extensions, changes or new instructions.',null,'normal','https://epr.cpcb.gov.in/']
  ];
  for(const [title,description,due,priority,url] of tasks){
    await env.DB.prepare("INSERT INTO workspace_tasks(company_id,title,description,due_date,status,priority,source_url) VALUES(?,?,?,?,?,?,?)").bind(company.id,title,description,due,'open',priority,url).run();
  }
}
function redirect(url){return new Response(null,{status:302,headers:{location:url}})}
export default {async fetch(request,env){
  if(request.method==="OPTIONS")return new Response("",{headers:CORS});
  const u=new URL(request.url);
  try{
    if(u.pathname==="/api/health")return json({ok:true,service:"eprtrack",version:"v12-data-analyzer"});

    // Server-side CTA router: logged-in users go to dashboard; others go to account creation.
    if((u.pathname==="/save-track"||u.pathname==="/save-track/")&&request.method==="GET"){
      const user=await auth(request,env);
      return redirect(user?"/dashboard/":"/auth/?mode=register&next=/dashboard/");
    }

    if(u.pathname==="/api/calculator"&&request.method==="POST"){
      const b=await request.json(),role=String(b.role||"").toLowerCase(),cat=String(b.category||"").toUpperCase(),tonnes=Number(b.tonnes);
      if(!roles.has(role)||!["I","II","III","IV"].includes(cat)||!Number.isFinite(tonnes)||tonnes<0)return json({error:"Enter a valid role, category and quantity."},400);
      const r=await rules(env,request),rate=r.recycled_content_rate[cat];
      return json({fy:"2026-27",role,role_label:labels[role],category:cat,input_tonnes:tonnes,recycled_content_rate:rate,indicative_recycled_content_tonnes:rate==null?null:tonnes*rate,minimum_recycling_rate_of_applicable_target:r.minimum_recycling_of_applicable_target[cat],rule_version:r.version,source:r.source,verified_on:r.verified_on});
    }

    if(u.pathname==="/api/auth/register"&&request.method==="POST"){
      const b=await request.json(),email=String(b.email||"").trim().toLowerCase(),pw=String(b.password||"");
      if(!/^\S+@\S+\.\S+$/.test(email)||pw.length<8)return json({error:"Enter a valid email and a password of at least 8 characters."},400);
      const existing=await env.DB.prepare("SELECT id FROM users WHERE email=? LIMIT 1").bind(email).first();
      if(existing)return json({error:"An account with this email already exists. Sign in instead."},409);
      const passwordHash=await hashPassword(pw);
      const userIdType=await columnType(env,"users","id");
      let userId;
      if(isIntegerType(userIdType)){
        const inserted=await env.DB.prepare("INSERT INTO users(email,password_hash) VALUES(?,?)").bind(email,passwordHash).run();
        userId=inserted.meta?.last_row_id;
        if(userId==null)throw new Error("User insert did not return an integer row id");
      }else{
        userId=crypto.randomUUID();
        await env.DB.prepare("INSERT INTO users(id,email,password_hash) VALUES(?,?,?)").bind(userId,email,passwordHash).run();
      }
      let t;
      try{
        t=token();
        const sessionCol=await getSessionColumn(env);
        await env.DB.prepare(`INSERT INTO sessions(${sessionCol},user_id,expires_at) VALUES(?,?,datetime('now','+30 day'))`).bind(t,userId).run();
      }catch(e){
        try{await env.DB.prepare("DELETE FROM users WHERE id=?").bind(userId).run()}catch(_){}
        throw e;
      }
      return json({ok:true,user:{id:userId,email}},201,{"set-cookie":sessionCookie(t)});
    }

    if(u.pathname==="/api/auth/login"&&request.method==="POST"){
      const b=await request.json(),email=String(b.email||"").trim().toLowerCase(),pw=String(b.password||"");
      const usr=await env.DB.prepare("SELECT id,email,password_hash FROM users WHERE email=? LIMIT 1").bind(email).first();
      if(!usr)return json({error:"No account found for this email. Create an account first."},401);
      if(!(await verifyPassword(pw,usr.password_hash)))return json({error:"Incorrect password."},401);
      const t=token();const sessionCol=await getSessionColumn(env);await env.DB.prepare(`INSERT INTO sessions(${sessionCol},user_id,expires_at) VALUES(?,?,datetime('now','+30 day'))`).bind(t,usr.id).run();
      return json({ok:true,user:{id:usr.id,email:usr.email}},200,{"set-cookie":sessionCookie(t)});
    }

    const user=await auth(request,env);
    if(user && request.method!=="GET" && !sameOrigin(request))return json({error:"Cross-site request blocked"},403);
    if(u.pathname==="/api/auth/logout"&&request.method==="POST"){
      const sid=cookieValue(request);if(sid){const sessionCol=await getSessionColumn(env);await env.DB.prepare(`DELETE FROM sessions WHERE ${sessionCol}=?`).bind(sid).run();}
      return json({ok:true},200,{"set-cookie":clearSessionCookie()});
    }
    if(!user)return json({error:"Authentication required"},401);

    if(u.pathname==="/api/me")return json({user});
    if(u.pathname==="/api/companies"&&request.method==="GET"){
      const r=await env.DB.prepare("SELECT id,legal_name,role,category,state,fy,created_at,updated_at FROM companies WHERE user_id=? ORDER BY created_at DESC").bind(user.id).all();
      return json(r.results||[]);
    }
    if(u.pathname==="/api/companies"&&request.method==="POST"){
      const existingCompany=await env.DB.prepare("SELECT id,legal_name FROM companies WHERE user_id=? ORDER BY created_at ASC LIMIT 1").bind(user.id).first();
      if(existingCompany)return json({error:"Your account already has a company workspace. One company is included in the current testing version; multiple companies will be available in a future Business plan."},409);
      const b=await request.json(),legalName=String(b.legal_name||"").trim(),role=String(b.role||"").toLowerCase(),category=String(b.category||"").toUpperCase(),state=String(b.state||"").trim(),fy=String(b.fy||"2026-27");
      if(!legalName||!roles.has(role)||!["I","II","III","IV"].includes(category))return json({error:"Company name, role and packaging category are required."},400);
      const companyIdType=await columnType(env,"companies","id");
      let id;
      if(isIntegerType(companyIdType)){
        const inserted=await env.DB.prepare("INSERT INTO companies(user_id,legal_name,role,category,state,fy,created_at,updated_at) VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)").bind(user.id,legalName,role,category,state,fy).run();
        id=inserted.meta?.last_row_id;
        if(id==null)throw new Error("Company insert did not return an integer row id");
      }else{
        id=crypto.randomUUID();
        await env.DB.prepare("INSERT INTO companies(id,user_id,legal_name,role,category,state,fy,created_at,updated_at) VALUES(?,?,?,?,?,?,?,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)").bind(id,user.id,legalName,role,category,state,fy).run();
      }
      return json({id,legal_name:legalName,role,category,state,fy});
    }
    if(u.pathname==="/api/tasks"&&request.method==="GET"){
      const cid=Number(u.searchParams.get('company_id'));
      const company=await ownership(env,user.id,cid);if(!company)return json({error:'Company not found'},404);
      await seedWorkspaceTasks(env,company);
      const r=await env.DB.prepare("SELECT id,title,description,due_date,status,priority,source_url,created_at,completed_at FROM workspace_tasks WHERE company_id=? ORDER BY CASE WHEN status='open' THEN 0 ELSE 1 END, CASE WHEN due_date IS NULL THEN 1 ELSE 0 END, due_date ASC, id ASC").bind(company.id).all();
      return json(r.results||[]);
    }
    if(u.pathname==="/api/tasks"&&request.method==="POST"){
      const b=await request.json();const cid=Number(b.company_id);const company=await ownership(env,user.id,cid);if(!company)return json({error:'Company not found'},404);
      await ensureWorkspaceTasks(env);
      const title=String(b.title||'').trim();if(!title)return json({error:'Task title is required'},400);
      const description=String(b.description||'').trim();const due=b.due_date?String(b.due_date):null;const priority=['low','normal','high'].includes(String(b.priority))?String(b.priority):'normal';
      await env.DB.prepare("INSERT INTO workspace_tasks(company_id,title,description,due_date,status,priority,source_url) VALUES(?,?,?,?,?,?,?)").bind(company.id,title,description,due,'open',priority,String(b.source_url||'')).run();
      return json({ok:true});
    }
    if(u.pathname==="/api/tasks"&&request.method==="PATCH"){
      const b=await request.json();const id=Number(b.id);const task=await env.DB.prepare("SELECT * FROM workspace_tasks WHERE id=?").bind(id).first();if(!task)return json({error:'Task not found'},404);
      const company=await ownership(env,user.id,task.company_id);if(!company)return json({error:'Task not found'},404);
      const status=b.status==='done'?'done':'open';await env.DB.prepare("UPDATE workspace_tasks SET status=?,completed_at=? WHERE id=?").bind(status,status==='done'?new Date().toISOString():null,id).run();
      return json({ok:true});
    }
    if(u.pathname==="/api/compliance"&&request.method==="GET"){
      const cid=u.searchParams.get("company_id");const company=await ownership(env,user.id,cid);if(!company)return json({error:"Company not found"},404);
      const profile=await env.DB.prepare("SELECT * FROM compliance_profiles WHERE company_id=?").bind(cid).first();
      return json({company,profile:profile||null});
    }
    if(u.pathname==="/api/compliance"&&request.method==="PUT"){
      const b=await request.json(),company=await ownership(env,user.id,b.company_id);if(!company)return json({error:"Company not found"},404);
      const input=Number(b.input_tonnes);if(!Number.isFinite(input)||input<0)return json({error:"Enter a valid planning quantity."},400);
      const rate=b.recycled_content_rate==null?null:Number(b.recycled_content_rate),progress=Number(b.progress_tonnes||0);if(!Number.isFinite(progress)||progress<0)return json({error:"Enter a valid progress value."},400);
      await env.DB.prepare(`INSERT INTO compliance_profiles(company_id,input_tonnes,epr_target_tonnes,recycling_required_tonnes,recycled_content_rate,progress_tonnes,rule_version,source_url,verified_on) VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(company_id) DO UPDATE SET input_tonnes=excluded.input_tonnes,epr_target_tonnes=excluded.epr_target_tonnes,recycling_required_tonnes=excluded.recycling_required_tonnes,recycled_content_rate=excluded.recycled_content_rate,progress_tonnes=excluded.progress_tonnes,rule_version=excluded.rule_version,source_url=excluded.source_url,verified_on=excluded.verified_on`).bind(company.id,input,b.epr_target_tonnes??null,b.recycling_required_tonnes??null,rate,progress,String(b.rule_version||""),String(b.source_url||""),String(b.verified_on||"")).run();
      return json({ok:true});
    }
    return json({error:"Not found"},404);
  }catch(e){
    console.error("EPRTrack worker error",{path:u.pathname,method:request.method,name:e?.name||"Error",message:e?.message||String(e),stack:e?.stack||""});
    return json({error:"Account service is temporarily unavailable. Please try again in a moment."},500);
  }
}}

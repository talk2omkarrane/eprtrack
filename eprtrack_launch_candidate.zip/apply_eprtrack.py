from pathlib import Path
import re, subprocess, json
root=Path.cwd()
changes={}
def read(p): return (root/p).read_text()
def replace(s,a,b):
    if s.count(a)!=1: raise RuntimeError('Expected exactly one source anchor: '+a[:100])
    return s.replace(a,b,1)
worker=read('src/index.js')
worker=replace(worker,'const u=new URL(request.url);','const u=new URL(request.url);\n  if (!sameOrigin(request) && request.method!=="GET") return json({error:"Cross-site request blocked"},403);')
worker=replace(worker,'if(!user)return json({error:"Authentication required"},401);','''if(!user)return json({error:"Authentication required"},401);
    if(u.pathname==="/api/launch-records"){
      const body=request.method==="GET"?null:await request.json();
      const cid=request.method==="GET"?u.searchParams.get("company_id"):body.company_id;
      const company=await ownership(env,user.id,cid);
      if(!company)return json({error:"Company not found"},404);
      const key=String(company.id), fy=String(company.fy);
      if(request.method==="GET"){
        const h=await env.DB.prepare("SELECT summary FROM launch_health WHERE company_id=? AND fy=?").bind(key,fy).first();
        const e=await env.DB.prepare("SELECT id,ref,qty,party,status,note FROM launch_evidence WHERE company_id=? AND fy=? ORDER BY id DESC").bind(key,fy).all();
        return json({health:h?JSON.parse(h.summary):null,evidence:e.results||[]},200,{"cache-control":"no-store"});
      }
      if(request.method==="PUT"){
        const h=body.health||{}, out={file:String(h.file||"").slice(0,250),checkedAt:new Date().toISOString()};
        for(const k of ["records","valid","review","duplicates","missingPackaging","categoryIssues","packagingTonnes"]){const n=h[k];if(typeof n!=="number"||!Number.isFinite(n)||n<0||n>1e12||(k!=="packagingTonnes"&&!Number.isInteger(n)))return json({error:"Invalid summary"},400);out[k]=n;}
        if(out.valid+out.review!==out.records)return json({error:"Invalid record totals"},400);
        await env.DB.prepare("INSERT INTO launch_health(company_id,fy,summary) VALUES(?,?,?) ON CONFLICT(company_id,fy) DO UPDATE SET summary=excluded.summary").bind(key,fy,JSON.stringify(out)).run();return json({ok:true});
      }
      if(request.method==="POST"){
        const ref=String(body.ref||"").trim(),qty=body.qty,party=String(body.party||"").trim(),note=String(body.note||"").trim();
        if(!ref||ref.length>200||typeof qty!=="number"||!Number.isFinite(qty)||qty<=0||qty>1e9||party.length>200||note.length>1000)return json({error:"Invalid evidence"},400);
        const status=body.status==="reviewed"?"reviewed":"pending";
        if(status==="reviewed"&&(!party||!note))return json({error:"Enter issuer and review notes"},400);
        const result=await env.DB.prepare("INSERT OR IGNORE INTO launch_evidence(company_id,fy,ref,qty,party,status,note) VALUES(?,?,?,?,?,?,?)").bind(key,fy,ref,qty,party,status,note).run();
        if(!result.meta.changes)return json({error:"Reference already exists for this financial year"},409);
        return json({ok:true},201);
      }
      if(request.method==="PATCH"){
        const id=Number(body.id),note=String(body.note||"").trim();
        if(!Number.isSafeInteger(id)||id<=0||note.length>1000||!note)return json({error:"Review note required"},400);
        const r=await env.DB.prepare("UPDATE launch_evidence SET status=?,note=? WHERE id=? AND company_id=? AND fy=? AND party<>''").bind(body.status==="reviewed"?"reviewed":"pending",note,id,key,fy).run();
        return r.meta.changes?json({ok:true}):json({error:"Evidence not found or issuer missing"},404);
      }
      return json({error:"Method not allowed"},405);
    }''')
worker=replace(worker,'if(u.pathname==="/api/health")return json({ok:true,service:"eprtrack",version:"v12-data-analyzer"});','if(u.pathname==="/api/health"){await env.DB.prepare("SELECT 1 FROM launch_health LIMIT 1").all();return json({ok:true,service:"eprtrack",version:"launch-candidate"},200,{"cache-control":"no-store"});}')
worker=replace(worker,'const actual=await derivePassword(password,bytesFromHex(saltHex),iterations);\n  return actual===digest;','const actual=await derivePassword(password,bytesFromHex(saltHex),iterations);\n  if(actual.length!==digest.length)return false;let diff=0;for(let i=0;i<actual.length;i++)diff|=actual.charCodeAt(i)^digest.charCodeAt(i);return diff===0;')
worker=replace(worker,'iterations<1000||!saltHex||!digest','iterations<1000||iterations>600000||!saltHex||!digest')
worker=replace(worker,'const b=await request.json(),company=await ownership(env,user.id,b.company_id);if(!company)return json({error:"Company not found"},404);','''const b=await request.json(),company=await ownership(env,user.id,b.company_id);if(!company)return json({error:"Company not found"},404);
      for(const k of ["epr_target_tonnes","recycling_required_tonnes","recycled_content_rate"]){if(b[k]!=null&&(typeof b[k]!=="number"||!Number.isFinite(b[k])||b[k]<0))return json({error:"Invalid compliance value"},400);}''')
# Preserve calculator progress server-side with explicit planning-only operation.
worker=replace(worker,'const rate=b.recycled_content_rate==null?null:Number(b.recycled_content_rate),progress=Number(b.progress_tonnes||0);','''if(b.planning_only===true){
        await env.DB.prepare("INSERT INTO compliance_profiles(company_id,input_tonnes,rule_version) VALUES(?,?,?) ON CONFLICT(company_id) DO UPDATE SET input_tonnes=excluded.input_tonnes").bind(company.id,input,"planning-only").run();return json({ok:true});
      }
      const rate=b.recycled_content_rate==null?null:Number(b.recycled_content_rate),progress=Number(b.progress_tonnes||0);''')
changes['src/index.js']=worker
p='public/dashboard/index.html'; s=read(p)
s=replace(s,"if(localStorage.getItem(pendingKey))await savePending(chosen.id);","")
s=replace(s,"const p=localStorage.getItem(pendingKey);if(p)document.getElementById('pending').style.display='block';","")
s=replace(s,"const raw=localStorage.getItem('eprtrack_last_health_check');","const raw=launchData.health?JSON.stringify(launchData.health):null;")
s=replace(s,"activeProfile=d.profile;renderHealthCard();","activeProfile=d.profile;launchData=await api('/api/launch-records?company_id='+encodeURIComponent(cid));if(String(activeCompany)!==String(cid))return;renderHealthCard();renderLaunchEvidence();")
s=replace(s,"async function logout(){try{await api('/api/auth/logout',{method:'POST'})}catch(e){}location.href='/'}init();",'''async function logout(){try{await api('/api/auth/logout',{method:'POST'});location.href='/'}catch(e){alert(e.message)}}
let launchData={health:null,evidence:[]};
function renderLaunchEvidence(){
 let panel=document.getElementById('launchEvidence');if(!panel){panel=document.createElement('section');panel.id='launchEvidence';panel.className='card';document.getElementById('workspace').prepend(panel);}
 panel.replaceChildren();const title=document.createElement('h2');title.textContent='Evidence register';panel.append(title);
 const info=document.createElement('p');const reviewed=launchData.evidence.filter(x=>x.status==='reviewed').reduce((a,x)=>a+x.qty,0);info.textContent='User-reviewed quantity: '+reviewed.toFixed(2)+' t. Pending records excluded. Review is not CPCB verification; this register does not automatically alter the existing manually recorded progress.';panel.append(info);
 const form=document.createElement('form');form.innerHTML='<label>Reference<input name="ref" required maxlength="200"></label><label>Issuer<input name="party" required maxlength="200"></label><label>Quantity (tonnes)<input name="qty" type="number" required min="0.000001" step="any"></label><label>Notes<input name="note" maxlength="1000"></label><button class="btn" type="submit">Add pending evidence</button>';panel.append(form);
 const msg=document.createElement('p');panel.append(msg);form.onsubmit=async e=>{e.preventDefault();const cid=activeCompany,fd=new FormData(form);try{await api('/api/launch-records',{method:'POST',body:JSON.stringify({company_id:cid,ref:fd.get('ref'),party:fd.get('party'),qty:Number(fd.get('qty')),note:fd.get('note')})});await selectCompany(cid)}catch(e){msg.textContent=e.message}};
 for(const item of launchData.evidence){const row=document.createElement('p');row.textContent=item.ref+' · '+item.qty+' t · '+item.party+' · '+item.status+' · '+item.note+' ';const btn=document.createElement('button');btn.type='button';btn.textContent=item.status==='reviewed'?'Return to pending':'Mark user-reviewed';btn.onclick=async()=>{const note=prompt('Enter review or correction note');if(!note)return;const cid=activeCompany;try{await api('/api/launch-records',{method:'PATCH',body:JSON.stringify({company_id:cid,id:item.id,note,status:item.status==='reviewed'?'pending':'reviewed'})});await selectCompany(cid)}catch(e){msg.textContent=e.message}};row.append(btn);panel.append(row);}
}
init();''')
# Prevent unsafe URL schemes in legacy tasks.
s=replace(s,"const source=t.source_url?", "const source=/^https?:\\/\\//i.test(t.source_url||'')?")
changes[p]=s
p='public/analyzer/index.html';s=read(p)
a="localStorage.setItem('eprtrack_last_health_check',JSON.stringify("
start=s.index(a); end=s.index('));const metrics=',start)
summary=s[start+len(a):end]
s=s[:start]+"offerLaunchSave("+summary+");const metrics="+s[end+len('));const metrics='):]
s=replace(s,'function renderResults(){','''function offerLaunchSave(health){
 let box=document.getElementById('launchSave');if(!box){box=document.createElement('div');box.id='launchSave';document.getElementById('resultsSection').prepend(box);}box.replaceChildren();
 const select=document.createElement('select'),button=document.createElement('button'),msg=document.createElement('p');button.textContent='Save analysis to company';button.className='btn';button.disabled=true;box.append(select,button,msg);
 fetch('/api/companies',{credentials:'same-origin'}).then(async r=>{if(!r.ok)throw Error('Sign in and create a company to save this summary.');const companies=await r.json();for(const c of companies){const o=document.createElement('option');o.value=c.id;o.textContent=c.legal_name+' · '+c.fy;select.append(o);}button.disabled=!companies.length;if(!companies.length)msg.textContent='Create a company before saving.';}).catch(e=>msg.textContent=e.message);
 button.onclick=async()=>{button.disabled=true;try{const r=await fetch('/api/launch-records',{method:'PUT',headers:{'content-type':'application/json'},body:JSON.stringify({company_id:select.value,health})});const d=await r.json();if(!r.ok)throw Error(d.error);msg.textContent='Summary saved. Open your dashboard to view it.';}catch(e){msg.textContent=e.message}finally{button.disabled=false}};
}
function renderResults(){''')
changes[p]=s
# Disable legacy browser-wide pending calculator writes. Calculator remains available.
for path in (root/'public/calculator').rglob('index.html'):
 p=str(path.relative_to(root));s=read(p)
 s=s.replace("localStorage.setItem('eprtrack_pending_calc',JSON.stringify(window.eprResult));",'')
 changes[p]=s
migration='''CREATE TABLE IF NOT EXISTS launch_health (company_id TEXT NOT NULL,fy TEXT NOT NULL,summary TEXT NOT NULL,PRIMARY KEY(company_id,fy));
CREATE TABLE IF NOT EXISTS launch_evidence (id INTEGER PRIMARY KEY AUTOINCREMENT,company_id TEXT NOT NULL,fy TEXT NOT NULL,ref TEXT NOT NULL COLLATE NOCASE,qty REAL NOT NULL CHECK(qty>0),party TEXT NOT NULL,status TEXT NOT NULL CHECK(status IN ('pending','reviewed')),note TEXT NOT NULL,UNIQUE(company_id,fy,ref));
'''
changes['migrations/0002_launch_records.sql']=migration
# Check all JS syntax before changing repository files.
import tempfile
with tempfile.TemporaryDirectory() as d:
 for p,s in changes.items():
  scripts=[s] if p.endswith('.js') else re.findall(r'<script(?:\s[^>]*)?>(.*?)</script>',s,re.S) if p.endswith('.html') else []
  for i,script in enumerate(scripts):
   f=Path(d)/'check.mjs';f.write_text(script);subprocess.run(['node','--check',str(f)],check=True)
for p,s in changes.items():
 f=root/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(s)
print('Applied',len(changes),'files. Existing wrangler.jsonc untouched. JavaScript syntax checks passed.')

EPRTrack launch candidate patch — apply from existing repository root.
This is an overlay installer, not a complete standalone app. It expects the V12 source anchors and aborts before writing if they differ. No wrangler configuration is included. Existing browser-local summaries/evidence are not migrated because they lack reliable account ownership. Existing D1 data is preserved. Payment remains disabled. Legal rates are unchanged and not freshly verified. Existing low-cost password hashing remains a public-launch blocker; paid Worker CPU capacity and rate limiting must be verified before public registration. Calculator result auto-save is disabled to prevent cross-account and progress overwrites. Evidence status is user-reviewed, not official verification.

Upload ZIP to Codespace repository root, then:
  unzip -o eprtrack_launch_candidate.zip -d /tmp/eprtrack-launch
  python3 /tmp/eprtrack-launch/apply_eprtrack.py
  git diff --stat
  npm install
  npx wrangler deploy --dry-run
  npx wrangler d1 migrations apply eprtrack-db --local
  npx wrangler dev

Do not deploy publicly until authentication, legal content, and local integration tests pass. No production deployment has been performed.

# EPRTrack V9 — Compliance workspace redesign

V9 keeps the working V8 auth/D1 schema compatibility and redesigns the dashboard around the actual SaaS value proposition.

## Dashboard tracking
- Company workspace
- Verified EPR target input
- Achieved/credited quantity input
- Target vs achieved progress
- Shortfall calculation
- Calculator planning snapshot kept separate from legal target
- Next-action workflow
- Responsive layout for desktop/tablet/mobile

## Product positioning
Free = one-time planning calculator.
Paid = recurring compliance workspace: FY records, target/achieved tracking, deadlines, evidence/certificate records, regulatory alerts and reports.

## Payments
Payment/checkout remains disabled. Pricing is informational only until product testing is complete.

## Important regulatory boundary
EPRTrack does not invent legal EPR targets. Users enter a verified target from their official CPCB records in this phase. The public calculator remains an indicative planning aid.

Keep the existing real wrangler.jsonc and D1 binding. Do not replace it with a package file.
